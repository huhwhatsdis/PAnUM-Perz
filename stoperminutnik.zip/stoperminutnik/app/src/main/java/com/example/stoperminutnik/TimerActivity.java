package com.example.stoperminutnik;

import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class TimerActivity extends AppCompatActivity {

    private TextView tvCountdown;

    private EditText etHours;
    private EditText etMinutes;
    private EditText etSeconds;

    private Button btnStart;
    private Button btnPause;
    private Button btnReset;
    private Button btnBack;

    private CountDownTimer countDownTimer;

    private long timeLeftMillis = 0;
    private boolean running = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timer);

        tvCountdown = findViewById(R.id.tvCountdown);

        etHours = findViewById(R.id.etHours);
        etMinutes = findViewById(R.id.etMinutes);
        etSeconds = findViewById(R.id.etSeconds);

        btnStart = findViewById(R.id.btnStartTimer);
        btnPause = findViewById(R.id.btnPauseTimer);
        btnReset = findViewById(R.id.btnResetTimer);
        btnBack = findViewById(R.id.btnBack);

        btnStart.setOnClickListener(v -> {

            if (!running) {

                if (timeLeftMillis == 0) {

                    String h = etHours.getText().toString().trim();
                    String m = etMinutes.getText().toString().trim();
                    String s = etSeconds.getText().toString().trim();

                    if (h.isEmpty() && m.isEmpty() && s.isEmpty()) {

                        Toast.makeText(
                                TimerActivity.this,
                                "Podaj czas odliczania",
                                Toast.LENGTH_SHORT
                        ).show();

                        return;
                    }

                    int hours =
                            h.isEmpty() ? 0 : Integer.parseInt(h);

                    int minutes =
                            m.isEmpty() ? 0 : Integer.parseInt(m);

                    int seconds =
                            s.isEmpty() ? 0 : Integer.parseInt(s);

                    long totalSeconds =
                            hours * 3600L +
                                    minutes * 60L +
                                    seconds;

                    timeLeftMillis = totalSeconds * 1000;
                }

                startTimer();
            }
        });

        btnPause.setOnClickListener(v -> {

            if (running && countDownTimer != null) {
                countDownTimer.cancel();
                running = false;
            }
        });

        btnReset.setOnClickListener(v -> {

            if (countDownTimer != null) {
                countDownTimer.cancel();
            }

            running = false;
            timeLeftMillis = 0;

            etHours.setText("");
            etMinutes.setText("");
            etSeconds.setText("");

            tvCountdown.setText("00:00:00");
        });

        btnBack.setOnClickListener(v -> finish());
    }

    private void startTimer() {

        countDownTimer =
                new CountDownTimer(timeLeftMillis, 1000) {

                    @Override
                    public void onTick(long millisUntilFinished) {

                        timeLeftMillis = millisUntilFinished;

                        updateTimeDisplay();
                    }

                    @Override
                    public void onFinish() {

                        running = false;
                        timeLeftMillis = 0;

                        tvCountdown.setText("00:00:00");

                        Toast.makeText(
                                TimerActivity.this,
                                "Czas minął!",
                                Toast.LENGTH_SHORT
                        ).show();

                        ToneGenerator toneGen =
                                new ToneGenerator(
                                        AudioManager.STREAM_MUSIC,
                                        100);

                        toneGen.startTone(
                                ToneGenerator.TONE_CDMA_ALERT_INCALL_LITE,
                                1000
                        );
                    }
                };

        countDownTimer.start();
        running = true;
    }

    private void updateTimeDisplay() {

        long totalSeconds = timeLeftMillis / 1000;

        long hours = totalSeconds / 3600;
        long minutes = (totalSeconds % 3600) / 60;
        long seconds = totalSeconds % 60;

        String time = String.format(
                "%02d:%02d:%02d",
                hours,
                minutes,
                seconds
        );

        tvCountdown.setText(time);
    }
}