package com.example.stoperminutnik;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView tvTime;
    private Button btnStart, btnPause, btnReset, btnTimer;

    private Handler handler = new Handler();

    private long startTime = 0L;
    private long timeBuffer = 0L;
    private long updateTime = 0L;

    private boolean running = false;

    Runnable runnable = new Runnable() {
        @Override
        public void run() {

            long millis = SystemClock.uptimeMillis() - startTime;
            updateTime = timeBuffer + millis;

            int seconds = (int) (updateTime / 1000);
            int minutes = seconds / 60;

            seconds %= 60;

            int hundredths = (int)((updateTime % 1000) / 10);

            tvTime.setText(String.format("%02d:%02d.%02d",
                    minutes, seconds, hundredths));

            handler.postDelayed(this, 10);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvTime = findViewById(R.id.tvTime);
        btnStart = findViewById(R.id.btnStart);
        btnPause = findViewById(R.id.btnPause);
        btnReset = findViewById(R.id.btnReset);
        btnTimer = findViewById(R.id.btnTimer);

        btnStart.setOnClickListener(v -> {
            if (!running) {
                startTime = SystemClock.uptimeMillis();
                handler.postDelayed(runnable, 0);
                running = true;
            }
        });

        btnPause.setOnClickListener(v -> {
            if (running) {
                timeBuffer += SystemClock.uptimeMillis() - startTime;
                handler.removeCallbacks(runnable);
                running = false;
            }
        });

        btnReset.setOnClickListener(v -> {
            startTime = 0L;
            timeBuffer = 0L;
            updateTime = 0L;
            running = false;

            handler.removeCallbacks(runnable);

            tvTime.setText("00:00.00");
        });

        btnTimer.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this,
                    TimerActivity.class);
            startActivity(intent);
        });
    }
}