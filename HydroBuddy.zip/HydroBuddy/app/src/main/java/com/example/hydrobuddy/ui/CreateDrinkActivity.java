package com.example.hydrobuddy.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import com.example.hydrobuddy.R;
import com.example.hydrobuddy.data.AppDatabase;
import com.example.hydrobuddy.data.DrinkEntity;
import java.util.Arrays;

public class CreateDrinkActivity extends BaseActivity {

    private EditText etName, etAmount;
    private Spinner spinnerCategory;
    private CheckBox cbFav;
    private Button btnSaveToListOnly, btnDrinkNow, btnDeleteDrink;

    private boolean isEditMode = false;
    private int editDrinkId = -1;
    private DrinkEntity existingDrink;
    private final String[] categories = {"Woda", "Sok", "Kawa", "Herbata", "Izotonik", "Mleko", "Napój gazowany", "Alkohol"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_drink);

        etName = findViewById(R.id.etName);
        etAmount = findViewById(R.id.etAmount);
        spinnerCategory = findViewById(R.id.spinnerCategory);
        cbFav = findViewById(R.id.cbFav);
        btnSaveToListOnly = findViewById(R.id.btnSaveToListOnly);
        btnDrinkNow = findViewById(R.id.btnDrinkNow);
        btnDeleteDrink = findViewById(R.id.btnDeleteDrink);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categories);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(adapter);

        setupNavigation(R.id.nav_create);

        if (getIntent().hasExtra("DRINK_ID")) {
            isEditMode = true;
            editDrinkId = getIntent().getIntExtra("DRINK_ID", -1);
            loadDrinkDataForEdit(editDrinkId);
        }

        btnSaveToListOnly.setOnClickListener(v -> saveDrink(false));
        btnDrinkNow.setOnClickListener(v -> saveDrink(true));
        btnDeleteDrink.setOnClickListener(v -> deleteDrinkFromDatabase());
    }

    private void loadDrinkDataForEdit(int id) {
        new Thread(() -> {
            try {
                existingDrink = AppDatabase.getInstance(getApplicationContext()).drinkDao().getDrinkById(id);
                if (existingDrink != null) {
                    runOnUiThread(() -> {
                        btnSaveToListOnly.setText("Zapisz zmiany");
                        btnDrinkNow.setText("Wypij i zapisz");
                        btnDeleteDrink.setVisibility(View.VISIBLE);

                        etName.setText(existingDrink.getName());
                        etAmount.setText(String.valueOf(existingDrink.getAmount()));
                        cbFav.setChecked(existingDrink.isFavorite());

                        int spinnerPosition = Arrays.asList(categories).indexOf(existingDrink.getCategory());
                        if (spinnerPosition >= 0) {
                            spinnerCategory.setSelection(spinnerPosition);
                        }
                    });
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

    private void saveDrink(boolean drinkNow) {
        String name = etName.getText().toString().trim();
        String amountStr = etAmount.getText().toString().trim();

        if (name.isEmpty() || amountStr.isEmpty()) {
            Toast.makeText(this, "Wypełnij wszystkie pola!", Toast.LENGTH_SHORT).show();
            return;
        }

        int amount = Integer.parseInt(amountStr);
        String category = spinnerCategory.getSelectedItem().toString();
        boolean isFav = cbFav.isChecked();

        new Thread(() -> {
            try {
                AppDatabase db = AppDatabase.getInstance(getApplicationContext());

                if (drinkNow) {
                    // Opcja 1: Zapisujemy zdarzenie wypicia w tabeli historii
                    DrinkEntity historyEntry = new DrinkEntity(name, amount, category, false, System.currentTimeMillis(), true);
                    db.drinkDao().insert(historyEntry);

                    // Jeśli nie byliśmy w trybie edycji, zapisujemy ten napój również jako szablon na przyszłość
                    if (!isEditMode) {
                        DrinkEntity template = new DrinkEntity(name, amount, category, isFav, 0, false);
                        db.drinkDao().insert(template);
                    }
                } else {
                    // Opcja 2: Tworzymy lub aktualizujemy tylko szablon napoju
                    DrinkEntity drink = isEditMode && existingDrink != null ? existingDrink : new DrinkEntity();
                    drink.setName(name);
                    drink.setAmount(amount);
                    drink.setCategory(category);
                    drink.setFavorite(isFav);
                    drink.setHistory(false);
                    drink.setTimestamp(0);

                    if (isEditMode) {
                        db.drinkDao().update(drink);
                    } else {
                        db.drinkDao().insert(drink);
                    }
                }

                runOnUiThread(() -> {
                    Toast.makeText(CreateDrinkActivity.this, "Pomyślnie zsynchronizowano z bazą danych!", Toast.LENGTH_SHORT).show();
                    finish();
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

    private void deleteDrinkFromDatabase() {
        if (existingDrink == null) return;
        new Thread(() -> {
            try {
                AppDatabase.getInstance(getApplicationContext()).drinkDao().delete(existingDrink);
                runOnUiThread(() -> {
                    Toast.makeText(CreateDrinkActivity.this, "Usunięto szablon napoju", Toast.LENGTH_SHORT).show();
                    finish();
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }
}