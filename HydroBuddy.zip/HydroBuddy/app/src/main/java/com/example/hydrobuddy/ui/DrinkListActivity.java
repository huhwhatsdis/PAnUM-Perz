package com.example.hydrobuddy.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.hydrobuddy.R;
import com.example.hydrobuddy.data.AppDatabase;
import com.example.hydrobuddy.data.DrinkDao;
import com.example.hydrobuddy.data.DrinkEntity;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DrinkListActivity extends BaseActivity {

    private RecyclerView recyclerView;
    private DrinkDao drinkDao;
    private final ExecutorService dbExecutor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drink_list);
        setupNavigation(R.id.nav_list);

        drinkDao = AppDatabase.getDatabase(this).drinkDao();
        recyclerView = findViewById(R.id.recyclerViewDrinks);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadDrinks();
    }

    private void loadDrinks() {
        dbExecutor.execute(() -> {
            List<DrinkEntity> list = drinkDao.getAllDrinks();
            runOnUiThread(() -> recyclerView.setAdapter(new DrinkAdapter(list)));
        });
    }

    private class DrinkAdapter extends RecyclerView.Adapter<DrinkAdapter.Holder> {
        List<DrinkEntity> dataset;
        DrinkAdapter(List<DrinkEntity> data) { this.dataset = data; }

        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_drink_row, parent, false);
            return new Holder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull Holder holder, int position) {
            DrinkEntity item = dataset.get(position);
            holder.tvTitle.setText(item.name + (item.isFavorite ? " ⭐" : ""));
            holder.tvSubtitle.setText(item.amountMl + " ml • Kategoria: " + item.category);

            holder.itemView.setOnClickListener(v -> {
                Intent intent = new Intent(DrinkListActivity.this, CreateDrinkActivity.class);
                intent.putExtra("DRINK_ID", item.id);
                startActivity(intent);
            });

            holder.itemView.setOnLongClickListener(v -> {
                dbExecutor.execute(() -> {
                    // Kluczowa poprawka: logujemy do historii (isHistory = true)
                    drinkDao.insert(new DrinkEntity(item.name, item.amountMl, item.category, false, System.currentTimeMillis(), true));
                    runOnUiThread(() -> Toast.makeText(DrinkListActivity.this, "Dodano do dzisiejszego bilansu: " + item.name, Toast.LENGTH_SHORT).show());
                });
                return true;
            });
        }

        @Override public int getItemCount() { return dataset.size(); }

        class Holder extends RecyclerView.ViewHolder {
            TextView tvTitle, tvSubtitle;
            Holder(View v) {
                super(v);
                tvTitle = v.findViewById(R.id.tvRowTitle);
                tvSubtitle = v.findViewById(R.id.tvRowSubtitle);
            }
        }
    }
}