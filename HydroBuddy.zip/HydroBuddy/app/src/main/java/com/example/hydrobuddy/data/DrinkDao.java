package com.example.hydrobuddy.data;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;

@Dao
public interface DrinkDao {
    @Insert
    void insert(DrinkEntity drink);

    @Update
    void update(DrinkEntity drink);

    @Delete
    void delete(DrinkEntity drink);

    @Query("SELECT * FROM drinks WHERE id = :id LIMIT 1")
    DrinkEntity getDrinkById(int id);

    // Pobiera ulubione szablony do szybkich przycisków na głównym ekranie
    @Query("SELECT * FROM drinks WHERE isFavorite = 1 AND isHistory = 0")
    List<DrinkEntity> getFavoriteDrinks();

    // Pobiera wyłącznie WYPITE napoje z wybranego zakresu czasu (dla kalendarza i szklanki)
    @Query("SELECT * FROM drinks WHERE timestamp >= :startTimestamp AND timestamp <= :endTimestamp AND isHistory = 1")
    List<DrinkEntity> getDrinksByDateRange(long startTimestamp, long endTimestamp);

    // Pobiera wyłącznie SZABLONY napojów (Twój stały zestaw)
    @Query("SELECT * FROM drinks WHERE isHistory = 0")
    List<DrinkEntity> getAllDrinks();

    // Zeruje tylko dzisiejsze wypite pozycje z historii
    @Query("DELETE FROM drinks WHERE timestamp >= :fromTimestamp AND isHistory = 1")
    void deleteDrinksFromToday(long fromTimestamp);
}