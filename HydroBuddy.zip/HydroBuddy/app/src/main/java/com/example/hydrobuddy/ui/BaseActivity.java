package com.example.hydrobuddy.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.example.hydrobuddy.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public abstract class BaseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        SharedPreferences prefs = getGetSharedPreferences();
        String theme = prefs.getString("APP_THEME", "mint");

        if (theme.equals("dark")) {
            setTheme(R.style.Theme_HydroBuddy_Dark);
        } else if (theme.equals("blue")) {
            setTheme(R.style.Theme_HydroBuddy);
        } else {
            setTheme(R.style.Theme_HydroBuddy_Mint);
        }

        super.onCreate(savedInstanceState);
    }

    private SharedPreferences getGetSharedPreferences() {
        return getSharedPreferences("HydroBuddyPrefs", MODE_PRIVATE);
    }

    protected void setupNavigation(int checkedItemId) {
        BottomNavigationView navView = findViewById(R.id.bottom_navigation);
        if (navView != null) {
            navView.setSelectedItemId(checkedItemId);
            navView.setOnItemSelectedListener(item -> {
                int id = item.getItemId();
                if (id == checkedItemId) return true;

                Intent intent = null;
                if (id == R.id.nav_home) {
                    intent = new Intent(this, MainActivity.class);
                } else if (id == R.id.nav_list) {
                    intent = new Intent(this, DrinkListActivity.class);
                } else if (id == R.id.nav_create) {
                    intent = new Intent(this, CreateDrinkActivity.class);
                } else if (id == R.id.nav_progress) {
                    intent = new Intent(this, ProgressActivity.class);
                } else if (id == R.id.nav_profile) {
                    intent = new Intent(this, ProfileActivity.class);
                }

                if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                    startActivity(intent);
                    overridePendingTransition(0, 0);
                }
                return true;
            });
        }
    }
}