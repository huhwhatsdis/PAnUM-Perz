package com.example.hydrobuddy.data;

public class HydrationCalculator {
    public static float getFactor(String category) {
        switch (category) {
            case "Woda": return 1.0f;
            case "Izotonik": return 1.2f;
            case "Herbata": return 0.9f;
            case "Mleko": return 0.95f;
            case "Sok": return 0.85f;
            case "Kawa": return 0.6f;
            case "Napój gazowany": return 0.7f;
            case "Alkohol": return -0.5f; // odwadnia!
            default: return 1.0f;
        }
    }
}