package com.example.hydrobuddy.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.hydrobuddy.R;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

public class ProfileActivity extends BaseActivity {

    private EditText etName, etWeight, etHeight;
    private Button btnSaveProfile;
    private ChipGroup chipGroupTheme;
    private Chip chipMint, chipBlue, chipDark;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        setupNavigation(R.id.nav_profile);

        etName = findViewById(R.id.etName);
        etWeight = findViewById(R.id.etWeight);
        etHeight = findViewById(R.id.etHeight);
        btnSaveProfile = findViewById(R.id.btnSaveProfile);
        chipGroupTheme = findViewById(R.id.chipGroupTheme);
        chipMint = findViewById(R.id.chipMint);
        chipBlue = findViewById(R.id.chipBlue);
        chipDark = findViewById(R.id.chipDark);

        SharedPreferences prefs = getSharedPreferences("HydroBuddyPrefs", MODE_PRIVATE);

        etName.setText(prefs.getString("USER_NAME", ""));
        etWeight.setText(prefs.getString("USER_WEIGHT", ""));
        etHeight.setText(prefs.getString("USER_HEIGHT", ""));

        String currentTheme = prefs.getString("APP_THEME", "mint");
        if (currentTheme.equals("blue")) chipBlue.setChecked(true);
        else if (currentTheme.equals("dark")) chipDark.setChecked(true);
        else chipMint.setChecked(true);

        btnSaveProfile.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String weightStr = etWeight.getText().toString().trim();
            String heightStr = etHeight.getText().toString().trim();

            String selectedThemeKey = "mint";
            if (chipBlue.isChecked()) selectedThemeKey = "blue";
            else if (chipDark.isChecked()) selectedThemeKey = "dark";

            // Obliczanie automatycznego celu na podstawie wagi użytkownika (np. 35ml na każdy kg)
            int calculatedGoal = 2000;
            if (!weightStr.isEmpty()) {
                try {
                    float weight = Float.parseFloat(weightStr);
                    calculatedGoal = (int) (weight * 35);
                    if (calculatedGoal < 1500) calculatedGoal = 1500; // Minimalny zdrowy próg
                } catch (NumberFormatException e) { e.printStackTrace(); }
            }

            SharedPreferences.Editor editor = prefs.edit();
            editor.putString("USER_NAME", name);
            editor.putString("USER_WEIGHT", weightStr);
            editor.putString("USER_HEIGHT", heightStr);
            editor.putInt("DAILY_GOAL", calculatedGoal); // Zapis jako INT

            boolean themeChanged = !selectedThemeKey.equals(currentTheme);
            editor.putString("APP_THEME", selectedThemeKey);
            editor.apply();

            Toast.makeText(this, "Zapisano! Cel dnia: " + calculatedGoal + " ml", Toast.LENGTH_SHORT).show();

            if (themeChanged) {
                Intent intent = new Intent(ProfileActivity.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
            }
        });
    }
}