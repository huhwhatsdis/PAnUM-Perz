package com.example.hydrobuddy.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "drinks")
public class DrinkEntity {
    @PrimaryKey(autoGenerate = true)
    public int id;

    public String name;
    public int amountMl;
    public String category; // Woda, Herbata, Kawa, Mleko, Alkohol, Sok, Izotonik, Napój gazowany
    public boolean isFavorite;
    public long timestamp;  // Kiedy wypito (dla historii)
    public boolean isHistory; // true = historia wypicia, false = szablon na liście napojów

    public DrinkEntity() {
    }

    public DrinkEntity(String name, int amountMl, String category, boolean isFavorite, long timestamp, boolean isHistory) {
        this.name = name;
        this.amountMl = amountMl;
        this.category = category;
        this.isFavorite = isFavorite;
        this.timestamp = timestamp;
        this.isHistory = isHistory;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getAmount() { return amountMl; }
    public void setAmount(int amount) { this.amountMl = amount; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public boolean isFavorite() { return isFavorite; }
    public void setFavorite(boolean favorite) { isFavorite = favorite; }

    public long getTimestamp() { return timestamp; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }

    public boolean isHistory() { return isHistory; }
    public void setHistory(boolean history) { isHistory = history; }
}