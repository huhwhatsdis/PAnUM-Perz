package com.example.hydrobuddy.data;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {DrinkEntity.class}, version = 4, exportSchema = false) // Wersja 4 ze względu na zmianę struktury encji
public abstract class AppDatabase extends RoomDatabase {

    public abstract DrinkDao drinkDao();
    private static volatile AppDatabase INSTANCE;
    private static final ExecutorService databaseWriteExecutor = Executors.newSingleThreadExecutor();

    public static AppDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    AppDatabase.class, "hydrobuddy_database")
                            .fallbackToDestructiveMigration()
                            .addCallback(roomDatabaseCallback)
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    public static AppDatabase getInstance(final Context context) {
        return getDatabase(context);
    }

    private static final RoomDatabase.Callback roomDatabaseCallback = new RoomDatabase.Callback() {
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            databaseWriteExecutor.execute(() -> {
                DrinkDao dao = INSTANCE.drinkDao();
                long now = System.currentTimeMillis();

                // Dodanie startowych szablonów (isHistory = false, woda jako domyślne ulubione)
                dao.insert(new DrinkEntity("Woda niegazowana", 250, "Woda", true, now, false));
                dao.insert(new DrinkEntity("Woda gazowana", 500, "Woda", false, now, false));
                dao.insert(new DrinkEntity("Zielona herbata", 250, "Herbata", false, now, false));
                dao.insert(new DrinkEntity("Czarna herbata", 250, "Herbata", false, now, false));
                dao.insert(new DrinkEntity("Kawa czarna", 200, "Kawa", false, now, false));
                dao.insert(new DrinkEntity("Kawa z mlekiem", 250, "Kawa", false, now, false));
                dao.insert(new DrinkEntity("Sok pomarańczowy", 250, "Sok", false, now, false));
                dao.insert(new DrinkEntity("Napój izotoniczny", 500, "Izotonik", false, now, false));
            });
        }
    };
}