package com.example.hydrobuddy.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.example.hydrobuddy.R;
import com.example.hydrobuddy.data.AppDatabase;
import com.example.hydrobuddy.data.DrinkEntity;
import java.util.Calendar;
import java.util.List;

public class MainActivity extends BaseActivity {

    private TextView tvHydrationText, tvCongratulation, tvPercentageText;
    private LinearLayout favButtonsContainer;
    private ProgressBar glassProgressBar;
    private TextView tvWaterFact;
    private int dailyGoal = 2000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvHydrationText = findViewById(R.id.tvHydrationText);
        tvPercentageText = findViewById(R.id.tvPercentageText);
        tvCongratulation = findViewById(R.id.tvCongratulation);
        favButtonsContainer = findViewById(R.id.favButtonsContainer);
        tvWaterFact = findViewById(R.id.tvWaterFact);
        glassProgressBar = findViewById(R.id.glassProgressBar);
        Button btnGoToAllList = findViewById(R.id.btnGoToAllList);

        setupNavigation(R.id.nav_home);

        btnGoToAllList.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, DrinkListActivity.class)));

        Button btnResetToday = findViewById(R.id.btnResetToday);
        btnResetToday.setOnClickListener(v -> resetDailyProgress());

        fetchWaterFactFromInternet();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Pobranie celu na bieżąco z profilu (zabezpieczenie przed twardym kodem)
        dailyGoal = getSharedPreferences("HydroBuddyPrefs", MODE_PRIVATE).getInt("DAILY_GOAL", 2000);
        loadDailyHydration();
    }

    private void loadDailyHydration() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 0); calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0); calendar.set(Calendar.MILLISECOND, 0);
        long startOfToday = calendar.getTimeInMillis();

        new Thread(() -> {
            try {
                AppDatabase db = AppDatabase.getInstance(getApplicationContext());
                List<DrinkEntity> todaysDrinks = db.drinkDao().getDrinksByDateRange(startOfToday, System.currentTimeMillis());
                List<DrinkEntity> favoriteDrinks = db.drinkDao().getFavoriteDrinks();

                int totalHydration = 0;
                for (DrinkEntity drink : todaysDrinks) {
                    totalHydration += drink.getAmount();
                }

                final int finalTotal = totalHydration;
                runOnUiThread(() -> {
                    updateGlassUI(finalTotal);
                    populateFavoriteButtons(favoriteDrinks);
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

    private void updateGlassUI(int currentHydration) {
        tvHydrationText.setText("Wypito: " + currentHydration + " / " + dailyGoal + " ml");

        int progress = (int) (((double) currentHydration / dailyGoal) * 100);
        if (progress > 100) progress = 100;

        glassProgressBar.setProgress(progress);
        tvPercentageText.setText(progress + "% celu na dziś");

        if (currentHydration >= dailyGoal) {
            tvCongratulation.setVisibility(View.VISIBLE);
            tvCongratulation.setText("Cel na dziś osiągnięty! 🎉");
        } else {
            tvCongratulation.setVisibility(View.INVISIBLE);
        }
    }

    private void populateFavoriteButtons(List<DrinkEntity> favorites) {
        favButtonsContainer.removeAllViews();

        if (favorites.isEmpty()) {
            TextView tvEmpty = new TextView(this);
            tvEmpty.setText("Brak ulubionych szablonów.");
            tvEmpty.setTextSize(14);
            tvEmpty.setGravity(android.view.Gravity.CENTER);
            favButtonsContainer.addView(tvEmpty);
            return;
        }

        android.util.TypedValue typedValue = new android.util.TypedValue();
        getTheme().resolveAttribute(com.google.android.material.R.attr.colorPrimaryContainer, typedValue, true);
        int colorContainer = typedValue.data;
        getTheme().resolveAttribute(com.google.android.material.R.attr.colorOnSurface, typedValue, true);
        int colorText = typedValue.data;

        for (DrinkEntity fav : favorites) {
            com.google.android.material.button.MaterialButton btn = new com.google.android.material.button.MaterialButton(this);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
            params.setMargins(8, 0, 8, 0);
            btn.setLayoutParams(params);

            btn.setText(fav.getName() + "\n" + fav.getAmount() + "ml");
            btn.setTextSize(12);
            btn.setCornerRadius(24);
            btn.setPadding(0, 24, 0, 24);
            btn.setBackgroundTintList(android.content.res.ColorStateList.valueOf(colorContainer));
            btn.setTextColor(colorText);

            btn.setOnClickListener(v -> new Thread(() -> {
                // Dodajemy rekord bezpośrednio do historii
                DrinkEntity drinkLog = new DrinkEntity(fav.getName(), fav.getAmount(), fav.getCategory(), false, System.currentTimeMillis(), true);
                AppDatabase.getInstance(getApplicationContext()).drinkDao().insert(drinkLog);
                runOnUiThread(this::loadDailyHydration);
            }).start());

            favButtonsContainer.addView(btn);
        }
    }

    private void resetDailyProgress() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 0); calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0); calendar.set(Calendar.MILLISECOND, 0);
        long startOfToday = calendar.getTimeInMillis();

        new Thread(() -> {
            try {
                AppDatabase.getInstance(getApplicationContext()).drinkDao().deleteDrinksFromToday(startOfToday);
                runOnUiThread(this::loadDailyHydration);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

    private void fetchWaterFactFromInternet() {
        new Thread(() -> {
            try {
                java.net.URL url = new java.net.URL("https://gist.githubusercontent.com/huhwhatsdis/616209da995202d88de318444a1e63e6/raw/0967c2c64dd113cba713a72af39fad7ddbab3648/water_facts.json");
                java.net.HttpURLConnection connection = (java.net.HttpURLConnection) url.openConnection();
                if (connection.getResponseCode() == 200) {
                    java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(connection.getInputStream(), "UTF-8"));
                    StringBuilder jsonBuilder = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) jsonBuilder.append(line);
                    reader.close();

                    org.json.JSONArray factsArray = new org.json.JSONArray(jsonBuilder.toString());
                    String randomFact = factsArray.getString(new java.util.Random().nextInt(factsArray.length()));
                    runOnUiThread(() -> tvWaterFact.setText("💡 Ciekawostka:\n" + randomFact));
                }
            } catch (Exception e) { e.printStackTrace(); }
        }).start();
    }
}