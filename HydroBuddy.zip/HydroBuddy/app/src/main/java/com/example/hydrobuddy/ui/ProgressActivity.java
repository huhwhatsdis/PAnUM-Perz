package com.example.hydrobuddy.ui;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.TextView;
import com.example.hydrobuddy.R;
import com.example.hydrobuddy.data.AppDatabase;
import com.example.hydrobuddy.data.DrinkDao;
import com.example.hydrobuddy.data.DrinkEntity;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ProgressActivity extends BaseActivity {

    private GridView gridView;
    private DrinkDao drinkDao;
    private final ExecutorService dbExecutor = Executors.newSingleThreadExecutor();
    private int targetMl;
    private final int[] dayStatusColors = new int[30];
    private int colorOnSurface; // Pobierany dynamicznie dla zachowania czytelności

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_progress);
        setupNavigation(R.id.nav_progress);

        drinkDao = AppDatabase.getInstance(this).drinkDao();
        gridView = findViewById(R.id.progressGridView);

        SharedPreferences prefs = getSharedPreferences("HydroBuddyPrefs", Context.MODE_PRIVATE);
        targetMl = prefs.getInt("DAILY_GOAL", 2000);

        // Pobranie koloru tekstu zgodnego z obecnym motywem
        android.util.TypedValue typedValue = new android.util.TypedValue();
        getTheme().resolveAttribute(com.google.android.material.R.attr.colorOnSurface, typedValue, true);
        colorOnSurface = typedValue.data;

        calculate30DaysProgress();
    }

    private void calculate30DaysProgress() {
        dbExecutor.execute(() -> {
            for (int i = 0; i < 30; i++) {
                Calendar cal = Calendar.getInstance();
                cal.add(Calendar.DAY_OF_YEAR, -i);

                cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0);
                long start = cal.getTimeInMillis();
                cal.set(Calendar.HOUR_OF_DAY, 23); cal.set(Calendar.MINUTE, 59); cal.set(Calendar.SECOND, 59);
                long end = cal.getTimeInMillis();

                List<DrinkEntity> dayDrinks = drinkDao.getDrinksByDateRange(start, end);

                if (dayDrinks.isEmpty()) {
                    dayStatusColors[29 - i] = Color.TRANSPARENT;
                } else {
                    int daySum = 0;
                    for (DrinkEntity d : dayDrinks) {
                        daySum += d.getAmount(); // Naprawiono odwołanie do getAmount()
                    }

                    if (daySum >= targetMl) {
                        dayStatusColors[29 - i] = Color.parseColor("#2E7D32"); // Głęboka zieleń Material
                    } else if (daySum >= (targetMl / 2)) {
                        dayStatusColors[29 - i] = Color.parseColor("#FBC02D"); // Ładny musztardowy żółty
                    } else {
                        dayStatusColors[29 - i] = Color.parseColor("#C62828"); // Subtelna czerwień
                    }
                }
            }

            runOnUiThread(() -> gridView.setAdapter(new GridAdapter()));
        });
    }

    private class GridAdapter extends BaseAdapter {
        @Override public int getCount() { return 30; }
        @Override public Object getItem(int p) { return null; }
        @Override public long getItemId(int p) { return p; }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView tv = new TextView(ProgressActivity.this);
            tv.setText(String.valueOf(position + 1));
            tv.setTextSize(16); // Zwiększony rozmiar czcionki
            tv.setTypeface(null, android.graphics.Typeface.BOLD); // POGRUBIONY NUMEREK
            tv.setGravity(android.view.Gravity.CENTER);

            GradientDrawable shape = new GradientDrawable();
            shape.setShape(GradientDrawable.OVAL);

            int statusColor = dayStatusColors[position];
            if (statusColor == Color.TRANSPARENT) {
                shape.setColor(Color.TRANSPARENT);
                // POGRUBIONA OTOCZKA (3dp zamiast 2dp) w kolorze dopasowanym do motywu
                shape.setStroke(3, colorOnSurface);
                tv.setTextColor(colorOnSurface);
            } else {
                shape.setColor(statusColor);
                tv.setTextColor(Color.WHITE); // Kontrastowy biały tekst wewnątrz pełnych dni
            }

            tv.setBackground(shape);

            int size = getResources().getDisplayMetrics().widthPixels / 8;
            GridView.LayoutParams params = new GridView.LayoutParams(size, size);
            tv.setLayoutParams(params);

            return tv;
        }
    }
}