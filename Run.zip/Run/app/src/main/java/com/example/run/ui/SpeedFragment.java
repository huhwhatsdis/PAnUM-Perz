package com.example.run.ui;

import android.os.Bundle;
import android.view.*;
import android.widget.*;

import androidx.fragment.app.Fragment;

import com.example.run.R;

public class SpeedFragment extends Fragment {

    EditText etSpeed, etDistance;
    TextView tvResult;

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {

        View view =
                inflater.inflate(R.layout.fragment_speed,
                        container,false);

        etSpeed = view.findViewById(R.id.etSpeed);
        etDistance = view.findViewById(R.id.etDistance);
        tvResult = view.findViewById(R.id.tvResult);

        Button btn = view.findViewById(R.id.btnCalc);

        btn.setOnClickListener(v -> calculate());

        return view;
    }

    private void calculate(){

        double speed =
                Double.parseDouble(etSpeed.getText().toString());

        double distance =
                Double.parseDouble(etDistance.getText().toString());

        double pace = 60.0 / speed;

        long marathonSec =
                (long)((42.195 / speed) * 3600);

        long halfSec =
                (long)((21.0975 / speed) * 3600);

        long customSec =
                (long)((distance / speed) * 3600);

        String result =
                "Tempo: "
                        + String.format("%.2f", pace)
                        + " min/km\n\n"

                        + "Maraton: "
                        + formatTime(marathonSec)
                        + "\n"

                        + "Półmaraton: "
                        + formatTime(halfSec)
                        + "\n"

                        + "Dystans "
                        + distance
                        + " km: "
                        + formatTime(customSec);

        tvResult.setText(result);
    }

    private String formatTime(long sec){

        long h = sec / 3600;
        long m = (sec % 3600) / 60;
        long s = sec % 60;

        return h + " h "
                + m + " min "
                + s + " s";
    }
}
