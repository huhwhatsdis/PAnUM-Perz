package com.example.run;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.example.run.ui.PaceFragment;
import com.example.run.ui.RequiredFragment;
import com.example.run.ui.SpeedFragment;

public class SectionsPagerAdapter extends FragmentStateAdapter {

    public SectionsPagerAdapter(AppCompatActivity activity) {
        super(activity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {

        switch(position){
            case 0:
                return new PaceFragment();

            case 1:
                return new SpeedFragment();

            default:
                return new RequiredFragment();
        }
    }

    @Override
    public int getItemCount() {
        return 3;
    }
}
