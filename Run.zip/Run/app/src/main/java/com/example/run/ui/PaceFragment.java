package com.example.run.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import androidx.fragment.app.Fragment;

import com.example.run.R;

public class PaceFragment extends Fragment {

    EditText etPace, etDistance;
    TextView tvResult;

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {

        View view =
                inflater.inflate(R.layout.fragment_pace,
                        container,false);

        etPace = view.findViewById(R.id.etPace);
        etDistance = view.findViewById(R.id.etDistance);
        tvResult = view.findViewById(R.id.tvResult);

        Button btn = view.findViewById(R.id.btnCalc);

        btn.setOnClickListener(v -> calculate());

        return view;
    }

    private void calculate(){

        double pace =
                Double.parseDouble(etPace.getText().toString());

        double distance =
                Double.parseDouble(etDistance.getText().toString());

        double speed = 60.0 / pace;

        long marathonSec =
                (long)(pace * 42.195 * 60);

        long halfSec =
                (long)(pace * 21.0975 * 60);

        long customSec =
                (long)(pace * distance * 60);

        String result =
                "Prędkość: "
                        + String.format("%.2f", speed)
                        + " km/h\n\n"

                        + "Maraton: "
                        + formatTime(marathonSec)
                        + "\n"

                        + "Półmaraton: "
                        + formatTime(halfSec)
                        + "\n"

                        + "Dystans "
                        + distance
                        + " km: "
                        + formatTime(customSec);

        tvResult.setText(result);
    }

    private String formatTime(long sec){

        long h = sec / 3600;
        long m = (sec % 3600) / 60;
        long s = sec % 60;

        return h + " h "
                + m + " min "
                + s + " s";
    }
}
