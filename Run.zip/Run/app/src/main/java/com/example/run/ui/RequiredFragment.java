package com.example.run.ui;

import android.os.Bundle;
import android.view.*;
import android.widget.*;

import androidx.fragment.app.Fragment;

import com.example.run.R;

public class RequiredFragment extends Fragment {

    EditText etDistance, etMinutes;
    TextView tvResult;

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {

        View view =
                inflater.inflate(
                        R.layout.fragment_required,
                        container,
                        false);

        etDistance = view.findViewById(R.id.etDistance);
        etMinutes = view.findViewById(R.id.etMinutes);
        tvResult = view.findViewById(R.id.tvResult);

        Button btn = view.findViewById(R.id.btnCalc);

        btn.setOnClickListener(v -> calculate());

        return view;
    }

    private void calculate(){

        double distance =
                Double.parseDouble(
                        etDistance.getText().toString());

        double minutes =
                Double.parseDouble(
                        etMinutes.getText().toString());

        double pace = minutes / distance;

        double speed = distance / (minutes / 60.0);

        String result =
                "Wymagane tempo: "
                        + String.format("%.2f", pace)
                        + " min/km\n\n"

                        + "Wymagana prędkość: "
                        + String.format("%.2f", speed)
                        + " km/h";

        tvResult.setText(result);
    }
}