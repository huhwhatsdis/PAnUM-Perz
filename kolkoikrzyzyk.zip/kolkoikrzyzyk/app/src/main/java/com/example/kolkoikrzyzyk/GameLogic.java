package com.example.kolkoikrzyzyk;

public class GameLogic {

    private static final int[][] WINNING_COMBINATIONS = {
            {0, 1, 2}, {3, 4, 5}, {6, 7, 8}, // Poziomy
            {0, 3, 6}, {1, 4, 7}, {2, 5, 8}, // Piony
            {0, 4, 8}, {2, 4, 6}             // Skosy
    };

    // Zwraca "X", "O" jeśli ktoś wygrał, "DRAW" jeśli remis, lub "" jeśli gramy dalej
    public static String checkBoardState(String[] board) {
        for (int[] combo : WINNING_COMBINATIONS) {
            if (!board[combo[0]].isEmpty() &&
                    board[combo[0]].equals(board[combo[1]]) &&
                    board[combo[0]].equals(board[combo[2]])) {
                return board[combo[0]];
            }
        }

        // Sprawdzenie czy są jeszcze wolne miejsca
        for (String cell : board) {
            if (cell.isEmpty()) return "";
        }

        return "DRAW";
    }
}
