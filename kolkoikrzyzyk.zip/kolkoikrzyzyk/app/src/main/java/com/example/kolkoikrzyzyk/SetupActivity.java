package com.example.kolkoikrzyzyk;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import androidx.appcompat.app.AppCompatActivity;
import com.example.kolkoikrzyzyk.databinding.ActivitySetupBinding;

public class SetupActivity extends AppCompatActivity {

    private ActivitySetupBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySetupBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.game_rounds_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.roundsSpinner.setAdapter(adapter);

        binding.startButton.setOnClickListener(v -> {
            String selectedText = binding.roundsSpinner.getSelectedItem().toString();
            // Wyciągamy cyfrę z tekstu np. "5 gier" -> 5
            int rounds = Integer.parseInt(selectedText.replaceAll("[^0-9]", ""));

            Intent intent = new Intent(SetupActivity.this, GameActivity.class);
            intent.putExtra("TOTAL_ROUNDS", rounds);
            startActivity(intent);
        });
    }
}