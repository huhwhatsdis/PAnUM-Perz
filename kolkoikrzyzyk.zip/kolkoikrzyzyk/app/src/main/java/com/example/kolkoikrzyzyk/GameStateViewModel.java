package com.example.kolkoikrzyzyk;

import androidx.lifecycle.ViewModel;

public class GameStateViewModel extends ViewModel {
    // Statystyki całego meczu
    public int totalRoundsToPlay = 5;
    public int roundsPlayed = 0;
    public double scoreX = 0;
    public double scoreO = 0;
    public int winsX = 0;
    public int winsO = 0;
    public int draws = 0;

    // Stan bieżącej planszy
    public String[] board = new String[9]; // "", "X", "O"
    public boolean isXTurn = true;
    public boolean isGameOverInRound = false;

    public GameStateViewModel() {
        resetBoard();
    }

    public void resetBoard() {
        for (int i = 0; i < 9; i++) {
            board[i] = "";
        }
        isXTurn = true;
        isGameOverInRound = false;
    }

    public void resetFullMatch() {
        roundsPlayed = 0;
        scoreX = 0;
        scoreO = 0;
        winsX = 0;
        winsO = 0;
        draws = 0;
        resetBoard();
    }
}