package com.example.kolkoikrzyzyk;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import com.example.kolkoikrzyzyk.databinding.ActivityGameBinding;

public class GameActivity extends AppCompatActivity {

    private ActivityGameBinding binding;
    private GameStateViewModel viewModel;
    private Button[] boardButtons;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityGameBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Inicjalizacja ViewModelu (odpornego na obracanie ekranu)
        viewModel = new ViewModelProvider(this).get(GameStateViewModel.class);

        // Pobranie danych startowych (tylko za pierwszym uruchomieniem meczu)
        if (savedInstanceState == null && getIntent().hasExtra("TOTAL_ROUNDS")) {
            viewModel.resetFullMatch();
            viewModel.totalRoundsToPlay = getIntent().getIntExtra("TOTAL_ROUNDS", 5);
        }

        initBoardButtons();
        updateUI();

        binding.buttonResetMatch.setOnClickListener(v -> {
            viewModel.resetFullMatch();
            finish(); // powrót do ekranu wyboru liczby gier
        });
    }

    private void initBoardButtons() {
        boardButtons = new Button[]{
                binding.b0, binding.b1, binding.b2,
                binding.b3, binding.b4, binding.b5,
                binding.b6, binding.b7, binding.b8
        };

        for (int i = 0; i < boardButtons.length; i++) {
            final int index = i;
            boardButtons[i].setOnClickListener(v -> onCellClicked(index));
        }
    }

    private void onCellClicked(int index) {
        if (!viewModel.board[index].isEmpty() || viewModel.isGameOverInRound) return;

        // Wykonaj ruch
        viewModel.board[index] = viewModel.isXTurn ? "X" : "O";
        viewModel.isXTurn = !viewModel.isXTurn;

        // Sprawdź stan pojedynczej rundy
        String result = GameLogic.checkBoardState(viewModel.board);
        if (!result.isEmpty()) {
            resolveRound(result);
        } else {
            updateUI();
        }
    }

    private void resolveRound(String result) {
        viewModel.isGameOverInRound = true;
        viewModel.roundsPlayed++;

        String message;
        if (result.equals("X")) {
            viewModel.scoreX += 1.0;
            viewModel.winsX++;
            message = "Rundę wygrywa Gracz X!";
        } else if (result.equals("O")) {
            viewModel.scoreO += 1.0;
            viewModel.winsO++;
            message = "Rundę wygrywa Gracz O!";
        } else {
            viewModel.scoreX += 0.5;
            viewModel.scoreO += 0.5;
            viewModel.draws++;
            message = "Remis w tej rundzie!";
        }

        updateUI();

        // Okno po zakończeniu pojedynczej rundy
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Koniec rundy")
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton("Następna runda", (dialog, id) -> {
                    if (viewModel.roundsPlayed >= viewModel.totalRoundsToPlay) {
                        showMatchSummary();
                    } else {
                        viewModel.resetBoard();
                        updateUI();
                    }
                })
                .show();
    }

    private void showMatchSummary() {
        String finalWinner;
        if (viewModel.scoreX > viewModel.scoreO) {
            finalWinner = "Zwycięzca meczu: Gracz X! 🏆";
        } else if (viewModel.scoreO > viewModel.scoreX) {
            finalWinner = "Zwycięzca meczu: Gracz O! 🏆";
        } else {
            finalWinner = "Mecz zakończył się ogólnym remisem! 🤝";
        }

        String summary = "Statystyki:\n" +
                "• Wygrane X: " + viewModel.winsX + "\n" +
                "• Wygrane O: " + viewModel.winsO + "\n" +
                "• Remisy: " + viewModel.draws + "\n\n" +
                "Końcowe punkty:\n" +
                "• Gracz X: " + viewModel.scoreX + " pkt\n" +
                "• Gracz O: " + viewModel.scoreO + " pkt\n\n" +
                finalWinner;

        new AlertDialog.Builder(this)
                .setTitle("Podsumowanie Meczu")
                .setMessage(summary)
                .setCancelable(false)
                .setPositiveButton("Zagraj Nowy Mecz", (dialog, id) -> {
                    viewModel.resetFullMatch();
                    finish();
                })
                .show();
    }

    private void updateUI() {
        // Odświeżenie przycisków na planszy
        for (int i = 0; i < boardButtons.length; i++) {
            boardButtons[i].setText(viewModel.board[i]);
            // Kolorowanie znaków dla lepszej czytelności
            if (viewModel.board[i].equals("X")) boardButtons[i].setTextColor(0xFFFF1744);
            else if (viewModel.board[i].equals("O")) boardButtons[i].setTextColor(0xFF29B6F6);
        }

        // Teksty informacyjne
        int remaining = viewModel.totalRoundsToPlay - viewModel.roundsPlayed;
        binding.textRoundsStatus.setText("Rozegrano: " + viewModel.roundsPlayed + " | Pozostało: " + remaining);
        binding.textScoreX.setText("Gracz X: " + viewModel.scoreX + " pkt");
        binding.textScoreO.setText("Gracz O: " + viewModel.scoreO + " pkt");
        binding.textCurrentTurn.setText("Ruch gracza: " + (viewModel.isXTurn ? "X" : "O"));
    }
}