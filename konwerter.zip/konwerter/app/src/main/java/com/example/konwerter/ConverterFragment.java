package com.example.konwerter;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.example.konwerter.databinding.FragmentConverterBinding;
import java.util.Locale;

public class ConverterFragment extends Fragment {

    private FragmentConverterBinding binding;
    private int modeType; // 0: Systemy, 1: Waluty, 2: Długość, 3: Powierzchnia

    public static ConverterFragment newInstance(int modeType) {
        ConverterFragment fragment = new ConverterFragment();
        Bundle args = new Bundle();
        args.putInt("mode_type", modeType);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            modeType = getArguments().getInt("mode_type");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentConverterBinding.inflate(inflater, container, false);
        setupSpinners();
        setupLiveConversion();
        return binding.getRoot();
    }

    private void setupSpinners() {
        int arrayResId;
        switch (modeType) {
            case 0: arrayResId = R.array.systems_array; break;
            case 1: arrayResId = R.array.currencies_array; break;
            case 2: arrayResId = R.array.length_array; break;
            default: arrayResId = R.array.area_array; break;
        }

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(requireContext(),
                arrayResId, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        binding.spinnerFrom.setAdapter(adapter);
        binding.spinnerTo.setAdapter(adapter);

        // Zmiana pozycji w spinnerze wyzwala ponowne przeliczenie
        AdapterView.OnItemSelectedListener listener = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { performConversion(); }
            @Override
            public void onNothingSelected(AdapterView<?> p) {}
        };

        binding.spinnerFrom.setOnItemSelectedListener(listener);
        binding.spinnerTo.setOnItemSelectedListener(listener);
    }

    private void setupLiveConversion() {
        binding.inputField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) { performConversion(); }
            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void performConversion() {
        String input = binding.inputField.getText().toString().trim();
        if (input.isEmpty()) {
            binding.resultField.setText("0");
            return;
        }

        String fromSelected = binding.spinnerFrom.getSelectedItem().toString();
        String toSelected = binding.spinnerTo.getSelectedItem().toString();

        if (modeType == 0) {
            // Konwersja Systemów Liczbowych
            String result = NumberSystemLogic.convert(input, fromSelected, toSelected);
            binding.resultField.setText(result);
        } else {
            // Konwersje Matematyczne (Waluty, Długość, Powierzchnia)
            try {
                // Zamiana przecinka na kropkę dla bezpieczeństwa wprowadzania liczb rzeczywistych
                double val = Double.parseDouble(input.replace(",", "."));
                double result = ConverterLogic.convertUnits(val, fromSelected, toSelected, modeType);

                // Formatowanie do max 6 miejsc po przecinku bez zbędnych zer
                binding.resultField.setText(String.format(Locale.US, "%.6f", result)
                        .replaceAll("0*$", "")
                        .replaceAll("\\.$", ""));
            } catch (NumberFormatException e) {
                binding.resultField.setText("BŁĄD: Niepoprawna liczba!");
            }
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView() ;
        binding = null;
    }
}