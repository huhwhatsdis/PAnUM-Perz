package com.example.konwerter;

public class NumberSystemLogic {

    // Walidacja danych wejściowych
    public static boolean isValid(String value, String system) {
        if (value == null || value.isEmpty()) return false;

        // Obsługa kropki dla systemów, jeśli to ułamek (głównie dla DEC)
        String regex;
        switch (system) {
            case "BIN": regex = "^[01]+(\\.[01]+)?$"; break;
            case "BASE-4": regex = "^[0-3]+(\\.[0-3]+)?$"; break;
            case "OCT": regex = "^[0-7]+(\\.[0-7]+)?$"; break;
            case "DEC": regex = "^[0-9]+(\\.[0-9]+)?$"; break;
            case "HEX": regex = "^[0-9a-fA-F]+(\\.[0-9a-fA-F]+)?$"; break;
            default: return false;
        }
        return value.matches(regex);
    }

    // Główna metoda konwertująca
    public static String convert(String value, String fromSys, String toSys) {
        if (!isValid(value, fromSys)) {
            return "BŁĄD: Niepoprawne znaki!";
        }

        try {
            // Rozdzielamy na część całkowitą i ułamkową
            String[] parts = value.split("\\.");
            long intPartInDec = convertToDecimalInt(parts[0], fromSys);

            double fracPartInDec = 0.0;
            if (parts.length > 1) {
                fracPartInDec = convertToDecimalFrac(parts[1], fromSys);
            }

            double totalDec = intPartInDec + fracPartInDec;

            if (toSys.equals("DEC")) {
                return String.valueOf(totalDec);
            }

            // Konwersja z DEC (totalDec) do docelowego
            String resInt = convertFromDecimalInt(intPartInDec, toSys);
            String resFrac = convertFromDecimalFrac(fracPartInDec, toSys);

            return resFrac.isEmpty() ? resInt : resInt + "." + resFrac;

        } catch (Exception e) {
            return "BŁĄD obliczeń!";
        }
    }

    private static int getRadix(String system) {
        switch (system) {
            case "BIN": return 2;
            case "BASE-4": return 4;
            case "OCT": return 8;
            case "HEX": return 16;
            default: return 10;
        }
    }

    private static long convertToDecimalInt(String part, String system) {
        return Long.parseLong(part, getRadix(system));
    }

    private static double convertToDecimalFrac(String part, String system) {
        int radix = getRadix(system);
        double result = 0.0;
        for (int i = 0; i < part.length(); i++) {
            int digit = Character.digit(part.charAt(i), radix);
            result += digit / Math.pow(radix, i + 1);
        }
        return result;
    }

    private static String convertFromDecimalInt(long value, String system) {
        int radix = getRadix(system);
        return Long.toString(value, radix).toUpperCase();
    }

    private static String convertFromDecimalFrac(double value, String system) {
        if (value == 0.0) return "";
        int radix = getRadix(system);
        StringBuilder sb = new StringBuilder();
        int precision = 6; // Ograniczenie do 6 miejsc po przecinku

        while (value > 0 && precision > 0) {
            value *= radix;
            int digit = (int) value;
            sb.append(Integer.toString(digit, radix).toUpperCase());
            value -= digit;
            precision--;
        }
        return sb.toString();
    }
}