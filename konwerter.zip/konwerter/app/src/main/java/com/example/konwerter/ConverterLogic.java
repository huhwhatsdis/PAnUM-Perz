package com.example.konwerter;

import java.util.HashMap;
import java.util.Map;

public class ConverterLogic {

    // 1. KURS WALUT (Baza: PLN = 1.0)
    // Stałe wartości łatwe do zmodyfikowania
    private static final Map<String, Double> CURRENCY_RATES = new HashMap<String, Double>() {{
        put("PLN", 1.0);
        put("USD", 4.00); // 1 USD = 4.00 PLN
        put("EUR", 4.30); // 1 EUR = 4.30 PLN
        put("GBP", 5.10); // 1 GBP = 5.10 PLN
        put("CHF", 4.50); // 1 CHF = 4.50 PLN
    }};

    // 2. JEDNOSTKI DŁUGOŚCI (Baza: metr = 1.0)
    private static final Map<String, Double> LENGTH_RATES = new HashMap<String, Double>() {{
        put("mm", 0.001);
        put("cm", 0.01);
        put("in", 0.0254);
        put("ft", 0.3048);
        put("yd", 0.9144);
        put("m", 1.0);
        put("km", 1000.0);
    }};

    // 3. JEDNOSTKI POWIERZCHNI (Baza: m² = 1.0)
    private static final Map<String, Double> AREA_RATES = new HashMap<String, Double>() {{
        put("mm²", 0.000001);
        put("cm²", 0.0001);
        put("m²", 1.0);
        put("km²", 1000000.0);
        put("ar", 100.0);
        put("ha", 10000.0);
    }};

    public static double convertUnits(double value, String fromUnit, String toUnit, int type) {
        Map<String, Double> rates;
        if (type == 1) rates = CURRENCY_RATES;
        else if (type == 2) rates = LENGTH_RATES;
        else rates = AREA_RATES;

        if (type == 1) {
            // Dla walut: Przelicz z waluty źródłowej na PLN, potem na docelową
            double valueInPLN = value * rates.get(fromUnit);
            return valueInPLN / rates.get(toUnit);
        } else {
            // Dla miar: Przelicz na jednostkę bazową (m lub m²), potem na docelową
            double valueInBase = value * rates.get(fromUnit);
            return valueInBase / rates.get(toUnit);
        }
    }
}